master module
=============

.. automodule:: master
   :members:
   :undoc-members:
   :show-inheritance:
