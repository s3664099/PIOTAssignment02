masterpi module
===============

.. automodule:: masterpi
   :members:
   :undoc-members:
   :show-inheritance:
