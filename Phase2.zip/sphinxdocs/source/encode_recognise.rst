encode\_recognise module
========================

.. automodule:: encode_recognise
   :members:
   :undoc-members:
   :show-inheritance:
