recognise module
================

.. automodule:: recognise
   :members:
   :undoc-members:
   :show-inheritance:
