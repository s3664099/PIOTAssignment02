encode module
=============

.. automodule:: encode
   :members:
   :undoc-members:
   :show-inheritance:
