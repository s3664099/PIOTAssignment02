db\_singleton module
====================

.. automodule:: db_singleton
   :members:
   :undoc-members:
   :show-inheritance:
